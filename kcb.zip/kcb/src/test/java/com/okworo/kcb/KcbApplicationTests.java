package com.okworo.kcb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KcbApplicationTests {

    @Test
    void contextLoads() {
    }

}
