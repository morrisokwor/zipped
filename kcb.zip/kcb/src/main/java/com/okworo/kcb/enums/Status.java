package com.okworo.kcb.enums;

/**
 * Author: Morris.Okworo
 * Date:12/3/2024
 */
public enum Status {
    TO_DO, IN_PROGRESS, DONE
}
